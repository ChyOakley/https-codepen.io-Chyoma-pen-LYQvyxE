# responsiveRegistrationForm

A Pen created on CodePen.io. Original URL: [https://codepen.io/Chyoma/pen/LYQvyxE](https://codepen.io/Chyoma/pen/LYQvyxE).

